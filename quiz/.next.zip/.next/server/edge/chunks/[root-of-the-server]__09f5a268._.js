(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["chunks/[root-of-the-server]__09f5a268._.js",
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[project]/src/lib/env.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Centralized environment helpers for API endpoints
// Public base URL for API requests from the browser. Defaults to Next.js rewrite proxy
__turbopack_context__.s([
    "apiBase",
    ()=>apiBase,
    "buildApiUrl",
    ()=>buildApiUrl
]);
const apiBase = ("TURBOPACK compile-time value", "http://api.quiz.test/api") || '/backend';
function buildApiUrl(path) {
    const base = apiBase.endsWith('/') ? apiBase.slice(0, -1) : apiBase;
    const suffix = path.startsWith('/') ? path : `/${path}`;
    return `${base}${suffix}`;
}
}),
"[project]/src/lib/auth.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PERMISSIONS",
    ()=>PERMISSIONS,
    "ROLE_PERMISSIONS",
    ()=>ROLE_PERMISSIONS,
    "USER_ROLES",
    ()=>USER_ROLES,
    "authOptions",
    ()=>authOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/providers/credentials.js [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$google$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/providers/google.js [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$facebook$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/providers/facebook.js [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/env.ts [middleware-edge] (ecmascript)");
;
;
;
const USER_ROLES = {
    GUEST: 'guest',
    USER: 'user',
    ADMIN: 'admin',
    SUPER_ADMIN: 'super_admin'
};
const PERMISSIONS = {
    // Quiz permissions
    CREATE_QUIZ: 'create_quiz',
    EDIT_QUIZ: 'edit_quiz',
    DELETE_QUIZ: 'delete_quiz',
    APPROVE_QUIZ: 'approve_quiz',
    // Course permissions
    CREATE_COURSE: 'create_course',
    EDIT_COURSE: 'edit_course',
    DELETE_COURSE: 'delete_course',
    APPROVE_COURSE: 'approve_course',
    // User management
    MANAGE_USERS: 'manage_users',
    MANAGE_ROLES: 'manage_roles',
    // System permissions
    VIEW_ANALYTICS: 'view_analytics',
    MANAGE_SETTINGS: 'manage_settings',
    MANAGE_WITHDRAWALS: 'manage_withdrawals'
};
const ROLE_PERMISSIONS = {
    [USER_ROLES.GUEST]: [],
    [USER_ROLES.USER]: [
        PERMISSIONS.CREATE_QUIZ,
        PERMISSIONS.EDIT_QUIZ,
        PERMISSIONS.DELETE_QUIZ,
        PERMISSIONS.CREATE_COURSE,
        PERMISSIONS.EDIT_COURSE,
        PERMISSIONS.DELETE_COURSE
    ],
    [USER_ROLES.ADMIN]: [
        PERMISSIONS.CREATE_QUIZ,
        PERMISSIONS.EDIT_QUIZ,
        PERMISSIONS.DELETE_QUIZ,
        PERMISSIONS.APPROVE_QUIZ,
        PERMISSIONS.CREATE_COURSE,
        PERMISSIONS.EDIT_COURSE,
        PERMISSIONS.DELETE_COURSE,
        PERMISSIONS.APPROVE_COURSE,
        PERMISSIONS.MANAGE_USERS,
        PERMISSIONS.VIEW_ANALYTICS,
        PERMISSIONS.MANAGE_WITHDRAWALS
    ],
    [USER_ROLES.SUPER_ADMIN]: Object.values(PERMISSIONS)
};
;
const authOptions = {
    providers: [
        // Email/Password Authentication
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$credentials$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["default"])({
            name: "credentials",
            credentials: {
                email: {
                    label: "Email",
                    type: "email"
                },
                password: {
                    label: "Password",
                    type: "password"
                }
            },
            async authorize (credentials) {
                console.log('NextAuth authorize called with:', {
                    email: credentials?.email
                });
                if (!credentials?.email || !credentials?.password) {
                    console.log('Missing credentials');
                    return null;
                }
                try {
                    console.log('Calling Laravel API at:', `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["apiBase"]}/auth/login`);
                    // Call Laravel API for authentication
                    const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["apiBase"]}/auth/login`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({
                            email: credentials.email,
                            password: credentials.password
                        })
                    });
                    console.log('Laravel API response status:', response.status);
                    if (!response.ok) {
                        console.log('Laravel API response not ok');
                        return null;
                    }
                    const data = await response.json();
                    console.log('Laravel API response data:', data);
                    const rawUser = data?.user || data?.data?.user;
                    const rawToken = data?.token || data?.data?.token;
                    console.log('Extracted user and token:', {
                        user: rawUser,
                        token: rawToken ? 'present' : 'missing'
                    });
                    if (rawUser && rawToken) {
                        // Determine role from property or first spatie role
                        const rawRole = rawUser.role || rawUser.roles?.[0]?.name;
                        const normalizedRole = rawRole === 'superadmin' || rawRole === 'super_admin' ? USER_ROLES.SUPER_ADMIN : rawRole === 'admin' ? USER_ROLES.ADMIN : USER_ROLES.USER;
                        // Use static role-permissions mapping (no extra API required)
                        const permissions = ROLE_PERMISSIONS[normalizedRole] || [];
                        const userResult = {
                            id: String(rawUser.id),
                            name: rawUser.name,
                            email: rawUser.email,
                            role: normalizedRole,
                            avatar: rawUser.avatar,
                            accessToken: rawToken,
                            permissions
                        };
                        console.log('Returning user result:', userResult);
                        return userResult;
                    }
                    console.log('Missing user or token in response');
                    return null;
                } catch (error) {
                    console.error('Authentication error:', error);
                    return null;
                }
            }
        }),
        // Conditionally enable socials only if properly configured
        ...process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET ? [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$google$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["default"])({
                clientId: process.env.GOOGLE_CLIENT_ID,
                clientSecret: process.env.GOOGLE_CLIENT_SECRET
            })
        ] : [],
        ...process.env.FACEBOOK_CLIENT_ID && process.env.FACEBOOK_CLIENT_SECRET ? [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$providers$2f$facebook$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["default"])({
                clientId: process.env.FACEBOOK_CLIENT_ID,
                clientSecret: process.env.FACEBOOK_CLIENT_SECRET
            })
        ] : []
    ],
    callbacks: {
        async signIn ({ user, account }) {
            console.log('NextAuth signIn callback called with:', {
                user,
                account
            });
            // Handle OAuth providers
            if (account?.provider === 'google' || account?.provider === 'facebook') {
                console.log('Handling OAuth provider:', account.provider);
                try {
                    // Check if user exists or create new user
                    const response = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["apiBase"]}/auth/social/${account.provider}/login`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({
                            provider: account.provider,
                            provider_id: account.providerAccountId,
                            name: user.name,
                            email: user.email,
                            avatar: user.image
                        })
                    });
                    if (response.ok) {
                        const data = await response.json();
                        if (data.success && data.user) {
                            // Fetch permissions from API
                            let permissions = [];
                            try {
                                const permissionsResponse = await fetch(`${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$env$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["apiBase"]}/auth/permissions`, {
                                    method: 'GET',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'Accept': 'application/json',
                                        'Authorization': `Bearer ${data.token}`
                                    }
                                });
                                if (permissionsResponse.ok) {
                                    const permissionsData = await permissionsResponse.json();
                                    permissions = permissionsData.permissions || [];
                                }
                            } catch  {
                                console.warn('Failed to fetch permissions from API, using fallback');
                                // Fallback to static permissions if API fails
                                permissions = ROLE_PERMISSIONS[data.user.role || USER_ROLES.USER] || [];
                            }
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            user.accessToken = data.token;
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            user.role = data.user.role;
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            user.permissions = permissions;
                            console.log('OAuth sign-in successful, returning true');
                            return true;
                        }
                    }
                    console.log('OAuth sign-in failed, returning false');
                    return false;
                } catch (error) {
                    console.error('OAuth sign-in error:', error);
                    return false;
                }
            }
            // For credentials provider, always return true if we get here
            // (the authorize function already validated the credentials)
            console.log('Credentials provider sign-in, returning true');
            return true;
        },
        async jwt ({ token, user, account }) {
            // Initial sign in
            if (account && user) {
                const customUser = user;
                token.accessToken = customUser.accessToken;
                token.role = customUser.role;
                token.permissions = customUser.permissions;
                token.avatar = customUser.avatar;
            }
            return token;
        },
        async session ({ session, token }) {
            // Send properties to the client
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            session.accessToken = token.accessToken;
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            session.user.id = token.sub;
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            session.user.role = token.role;
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            session.user.permissions = token.permissions;
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            session.user.avatar = token.avatar;
            return session;
        }
    },
    session: {
        strategy: "jwt",
        maxAge: 30 * 24 * 60 * 60
    },
    pages: {
        signIn: '/auth/signin',
        error: '/auth/error'
    },
    secret: process.env.NEXTAUTH_SECRET,
    // Add debug configuration
    debug: ("TURBOPACK compile-time value", "development") === 'development'
};
}),
"[project]/src/middleware.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "config",
    ()=>config,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$middleware$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-auth/middleware.js [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/web/exports/index.js [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth.ts [middleware-edge] (ecmascript)");
;
;
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$auth$2f$middleware$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["withAuth"])(function middleware(req) {
    const token = req.nextauth.token;
    const { pathname } = req.nextUrl;
    // Admin routes
    if (pathname.startsWith('/admin')) {
        if (!token) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/auth/signin', req.url));
        }
        const userRole = token.role;
        if (userRole !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["USER_ROLES"].ADMIN && userRole !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["USER_ROLES"].SUPER_ADMIN) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/unauthorized', req.url));
        }
        // Super admin only routes
        if (pathname.startsWith('/admin/settings') || pathname.startsWith('/admin/users') || pathname.startsWith('/admin/roles') || pathname.startsWith('/admin/permissions') || pathname.startsWith('/admin/categories')) {
            if (userRole !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["USER_ROLES"].SUPER_ADMIN && userRole !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["USER_ROLES"].ADMIN) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/unauthorized', req.url));
            }
        }
    }
    // Protected routes that require authentication
    if (pathname.startsWith('/dashboard') || pathname.startsWith('/profile') || pathname.startsWith('/learning')) {
        if (!token) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/auth/signin', req.url));
        }
    }
    // Quiz creation routes
    if (pathname.startsWith('/quiz/create') || pathname.startsWith('/course/create')) {
        if (!token) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/auth/signin', req.url));
        }
        const userRole = token.role;
        if (userRole !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["USER_ROLES"].USER && userRole !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["USER_ROLES"].ADMIN && userRole !== __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["USER_ROLES"].SUPER_ADMIN) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(new URL('/unauthorized', req.url));
        }
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
}, {
    callbacks: {
        authorized: ({ token, req })=>{
            // Allow access to public routes
            const publicRoutes = [
                '/',
                '/auth/signin',
                '/auth/signup',
                '/auth/forgot-password',
                '/auth/reset-password',
                '/auth/error',
                '/unauthorized',
                '/quiz',
                '/course',
                '/about',
                '/contact'
            ];
            const { pathname } = req.nextUrl;
            // Check if it's a public route
            if (publicRoutes.some((route)=>pathname.startsWith(route))) {
                return true;
            }
            // For all other routes, require authentication
            return !!token;
        }
    }
});
const config = {
    matcher: [
        '/admin/:path*',
        '/dashboard/:path*',
        '/profile/:path*',
        '/quiz/create/:path*',
        '/course/create/:path*',
        '/course/builder/:path*',
        '/learning/:path*',
        '/favorites'
    ]
};
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__09f5a268._.js.map