self.__BUILD_MANIFEST = {
  "/_error": [
    "./static/chunks/8db9625caaa00f9b.js"
  ],
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/backend/:path*"
      },
      {
        "source": "/api/backend/:path*"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()