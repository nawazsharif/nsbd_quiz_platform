(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_063d065d._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_6b238b06._.js"
],
    source: "dynamic"
});
