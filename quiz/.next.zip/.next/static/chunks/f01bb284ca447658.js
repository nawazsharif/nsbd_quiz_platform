__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/f61c16128e887da4.js",
  "static/chunks/turbopack-ce215289a8fd54bd.js"
])
