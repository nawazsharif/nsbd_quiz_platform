(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_02633351._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_1d0d9ebb._.js"
],
    source: "dynamic"
});
