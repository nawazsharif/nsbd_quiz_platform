(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_20dedeb1._.js",
  "static/chunks/node_modules_recharts_es6_b07fad1b._.js",
  "static/chunks/node_modules_03c2d6ff._.js"
],
    source: "dynamic"
});
